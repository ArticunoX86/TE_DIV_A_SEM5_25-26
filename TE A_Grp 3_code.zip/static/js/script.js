window.addEventListener("load", () => {
  const splash = document.getElementById("splash");
  const lights = document.querySelectorAll(".light");
  const startSound = document.getElementById("startSound");
  const logo = document.getElementById("logo");

  // Step 1: Play sound
  startSound.volume = 0.5;
  startSound.play().catch(() => {}); // Avoid autoplay errors

  // Step 2: Animate lights
  lights.forEach((light, index) => {
    setTimeout(() => {
      light.classList.add("active");
    }, 800 * index);
  });

  // Step 3: Show logo after lights
  setTimeout(() => {
    logo.classList.add("show");
  }, 4200);

  // Step 4: Fade out splash
  setTimeout(() => {
    splash.classList.add("fade-out");
  }, 6000);
});

// Prediction button logic
document.getElementById("predictBtn").addEventListener("click", async () => {
  const year = document.getElementById("yearInput").value;
  const resultSection = document.getElementById("resultSection");
  const tableBody = document.getElementById("resultsTable");

  resultSection.classList.add("hidden");
  const response = await fetch(`/predict?year=${year}`);
  const data = await response.json();

  tableBody.innerHTML = "";
  data.forEach(row => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="border border-gray-700 p-3">${row.raceName}</td>
      <td class="border border-gray-700 p-3">${row.driverRef}</td>
      <td class="border border-gray-700 p-3">${row.constructorRef}</td>
      <td class="border border-gray-700 p-3 text-center">${row.pred_rank}</td>
    `;
    tableBody.appendChild(tr);
  });

  resultSection.classList.remove("hidden");
  window.scrollTo({ top: resultSection.offsetTop, behavior: "smooth" });
});
