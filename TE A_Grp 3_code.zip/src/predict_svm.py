import argparse
import os
import json
import joblib
import numpy as np
import pandas as pd
from features import build_dataset


def per_race_rank(pred_df: pd.DataFrame) -> pd.DataFrame:
    """Ranks drivers per race based on predicted finish (lower is better)."""
    pred_df = pred_df.copy()
    pred_df["pred_finish"] = pred_df["pred"].astype(float)
    pred_df["pred_rank"] = pred_df.groupby("raceId")["pred_finish"].rank(method="first")
    pred_df = pred_df.sort_values(["raceDateTime", "raceId", "pred_rank"])
    return pred_df


def main(args):
    # Load model and feature list
    if os.path.isdir(args.models_dir):
        files = [f for f in os.listdir(args.models_dir) if f.endswith(".joblib")]
        if not files:
            raise FileNotFoundError("❌ No model .joblib found in models_dir.")
        files.sort()
        model_path = os.path.join(args.models_dir, files[-1])
        base = os.path.splitext(files[-1])[0]
        feature_list_path = os.path.join(args.models_dir, base + "_features.json")
    else:
        model_path = args.models_dir
        feature_list_path = os.path.splitext(model_path)[0] + "_features.json"

    print(f"📂 Using model: {model_path}")

    # Load model data
    model_data = joblib.load(model_path)

    # --- START: SVM-ONLY ENFORCEMENT ---
    # We enforce the expectation that the loaded data is the SVM dictionary format: 
    # {'model': <model_object>, 'scaler': <scaler_object>, 'imputer': <imputer_object>}
    
    if not isinstance(model_data, dict):
        raise TypeError(
            "❌ Model file must be a dictionary (SVM format) containing 'model', "
            "and optionally 'scaler' and 'imputer'."
        )
    
    if "model" not in model_data:
        raise ValueError("❌ Model dictionary must contain the 'model' key.")
        
    model = model_data["model"]
    # Use .get() for optional components (like if no imputer/scaler was used)
    scaler = model_data.get("scaler")
    imputer = model_data.get("imputer")
    # --- END: SVM-ONLY ENFORCEMENT ---

    # Load feature columns
    with open(feature_list_path, "r", encoding="utf-8") as f:
        feature_cols = json.load(f)

    # Load dataset
    df, _ = build_dataset(args.data_dir)

    print(f"📊 Loaded {len(df)} samples for prediction")

    # Apply preprocessing
    X = df[feature_cols].copy()

    # Handle NaNs
    if imputer:
        # X is converted to numpy array if imputer is used (imputer.transform returns numpy array)
        X = imputer.transform(X)
    else:
        # Convert to numpy array for models that expect it, handling NaNs
        X = X.to_numpy()
        X = np.nan_to_num(X)

    # Scale
    if scaler:
        X = scaler.transform(X)

    # Predict all years (no filtering)
    print("🚀 Predicting for all races...")
    preds = model.predict(X)
    df["pred"] = preds

    # Rank predictions per race
    ranked = per_race_rank(df)

    # Save predictions
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    cols = [
        "raceId", "raceName", "raceDateTime", "driverId", "driverRef",
        "constructorId", "constructorRef", "pred", "pred_rank", "positionOrder"
    ]
    ranked[cols].to_csv(args.out, index=False)

    print(f"\n✅ Wrote predictions to: {args.out}")
    print(ranked[cols].head(20).to_string(index=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=str, default="data/raw")
    parser.add_argument("--models-dir", type=str, default="models", help="Directory containing model or path to a .joblib file")
    parser.add_argument("--out", type=str, default="data/processed/predictions.csv")
    args = parser.parse_args()
    main(args)
