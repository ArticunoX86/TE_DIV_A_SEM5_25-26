# src/features.py (extended + fixed + warnings suppressed)
import pandas as pd
import numpy as np
from dateutil import parser
from sklearn.preprocessing import LabelEncoder
import warnings

# Suppress FutureWarnings (like groupby.apply ones)
warnings.filterwarnings("ignore", category=FutureWarning)

COLS = {
    "races": {"raceId":"raceId","year":"year","round":"round","circuitId":"circuitId","name":"raceName","date":"date","time":"time"},
    "results":{"raceId":"raceId","driverId":"driverId","constructorId":"constructorId","grid":"grid","positionOrder":"positionOrder","points":"points","statusId":"statusId"},
    "drivers":{"driverId":"driverId","driverRef":"driverRef","dob":"dob"},
    "constructors":{"constructorId":"constructorId","constructorRef":"constructorRef","name":"constructorName"},
    "qualifying":{"raceId":"raceId","driverId":"driverId","constructorId":"constructorId","position":"q_position","q1":"q1","q2":"q2","q3":"q3"}
}

def _parse_datetime(date_str, time_str):
    if pd.isna(date_str):
        return pd.NaT
    dt_str = str(date_str)
    if pd.notna(time_str):
        dt_str = f"{date_str} {time_str}"
    try:
        return parser.parse(dt_str)
    except Exception:
        return pd.to_datetime(date_str, errors="coerce")

def _time_to_seconds(x):
    if pd.isna(x): return np.nan
    s = str(x).strip().lower()
    if s in ("\\N","","nan","none"): return np.nan
    try:
        if ":" not in s: return float(s)
        parts=[float(p) for p in s.split(":")]
        if len(parts)==2: return parts[0]*60+parts[1]
        if len(parts)==3: return parts[0]*3600+parts[1]*60+parts[2]
        return np.nan
    except: return np.nan

def load_raw(data_dir: str):
    def read(name):
        return pd.read_csv(f"{data_dir}/{name}.csv", encoding="utf-8")
    races=read("races"); results=read("results"); drivers=read("drivers"); constructors=read("constructors"); qualy=read("qualifying")
    return {"races":races,"results":results,"drivers":drivers,"constructors":constructors,"qualifying":qualy}

def _normalize_columns(df, mapping):
    cols={src:mapping[src] for src in mapping if src in df.columns}
    return df.rename(columns=cols)

def build_dataset(data_dir: str):
    raw=load_raw(data_dir)
    races=_normalize_columns(raw["races"],COLS["races"])
    results=_normalize_columns(raw["results"],COLS["results"])
    drivers=_normalize_columns(raw["drivers"],COLS["drivers"])
    constructors=_normalize_columns(raw["constructors"],COLS["constructors"])
    qualy=_normalize_columns(raw["qualifying"],COLS["qualifying"])

    races["raceDateTime"]=races.apply(lambda r:_parse_datetime(r.get("date"),r.get("time")),axis=1)
    races=races[["raceId","year","round","circuitId","raceName","raceDateTime"]]

    df=results.merge(races,on="raceId",how="left")
    df=df.merge(drivers[["driverId","driverRef","dob"]],on="driverId",how="left")
    df=df.merge(constructors[["constructorId","constructorRef","constructorName"]],on="constructorId",how="left")

    qualy["q1_s"]=qualy["q1"].apply(_time_to_seconds)
    qualy["q2_s"]=qualy["q2"].apply(_time_to_seconds)
    qualy["q3_s"]=qualy["q3"].apply(_time_to_seconds)
    qualy=qualy.groupby(["raceId","driverId"]).agg(q_position=("q_position","min"),q1_s=("q1_s","min"),q2_s=("q2_s","min"),q3_s=("q3_s","min")).reset_index()
    df=df.merge(qualy,on=["raceId","driverId"],how="left")

    df["dob"]=pd.to_datetime(df["dob"],errors="coerce")
    df["driver_age_years"]=(df["raceDateTime"]-df["dob"]).dt.days/365.25
    df["quali_pos"]=df["q_position"].fillna(df["grid"])
    df["finish_pos"]=df["positionOrder"]
    df["start_finish_delta"]=df["finish_pos"]-df["grid"]

    # rolling features
    df=df.sort_values(["driverId","year","round","raceId"])
    def drv_roll(g):
        g=g.sort_values(["year","round"])
        for w in(3,5):
            g[f"drv_points_prev{w}"]=g["points"].shift(1).rolling(w,min_periods=1).sum()
            g[f"drv_avg_finish_prev{w}"]=g["finish_pos"].shift(1).rolling(w,min_periods=1).mean()
            g[f"drv_avg_grid_prev{w}"]=g["grid"].shift(1).rolling(w,min_periods=1).mean()
            g[f"drv_avg_delta_prev{w}"]=g["start_finish_delta"].shift(1).rolling(w,min_periods=1).mean()
        g["drv_races_prev5"]=g["raceId"].shift(1).rolling(5,min_periods=1).count()
        return g
    df = df.groupby("driverId", group_keys=False).apply(drv_roll)

    df=df.sort_values(["constructorId","year","round"])
    def team_roll(g):
        g=g.sort_values(["year","round"])
        for w in(3,5):
            g[f"team_points_prev{w}"]=g["points"].shift(1).rolling(w,min_periods=1).sum()
            g[f"team_avg_finish_prev{w}"]=g["finish_pos"].shift(1).rolling(w,min_periods=1).mean()
        return g
    df = df.groupby("constructorId", group_keys=False).apply(team_roll)

    df=df.sort_values(["driverId","circuitId","year","round"])
    def circ_roll(g):
        g=g.sort_values(["year","round"])
        g["drv_circuit_avg_finish_prev2"]=g["finish_pos"].shift(1).rolling(2,min_periods=1).mean()
        return g
    df = df.groupby(["driverId","circuitId"], group_keys=False).apply(circ_roll)

    # ------------------- Extra Features -------------------
    try:
        pit=pd.read_csv(f"{data_dir}/pit_stops.csv",encoding="utf-8")
        pit_sum=pit.groupby(["raceId","driverId"]).agg(pit_count=("stop","max"),avg_pit_ms=("milliseconds","mean"),min_pit_ms=("milliseconds","min"),max_pit_ms=("milliseconds","max")).reset_index()
        df=df.merge(pit_sum,on=["raceId","driverId"],how="left")
    except: 
        df["pit_count"]=df["avg_pit_ms"]=df["min_pit_ms"]=df["max_pit_ms"]=np.nan
    try:
        laps=pd.read_csv(f"{data_dir}/lap_times.csv",encoding="utf-8")
        lap_sum=laps.groupby(["raceId","driverId"]).agg(avg_lap_ms=("milliseconds","mean"),best_lap_ms=("milliseconds","min"),laps_completed=("lap","max")).reset_index()
        df=df.merge(lap_sum,on=["raceId","driverId"],how="left")
    except:
        df["avg_lap_ms"]=df["best_lap_ms"]=df["laps_completed"]=np.nan
    try:
        weather=pd.read_csv(f"{data_dir}/weather.csv",encoding="utf-8")
        df=df.merge(weather,on="raceId",how="left")
    except:
        df["airTemp"]=df["trackTemp"]=df["humidity"]=df["pressure"]=df["windSpeed"]=np.nan
        df["weatherDesc"]=np.nan
    if "weatherDesc" in df.columns:
        df["weatherDesc"]=df["weatherDesc"].astype(str).fillna("Unknown")
        le=LabelEncoder()
        df["weatherDesc"]=le.fit_transform(df["weatherDesc"])

    # Feature cols
    base_feats=["grid","quali_pos","driver_age_years","year","round",
        "drv_points_prev3","drv_avg_finish_prev3","drv_avg_grid_prev3","drv_avg_delta_prev3","drv_races_prev5",
        "drv_points_prev5","drv_avg_finish_prev5","drv_avg_grid_prev5","drv_avg_delta_prev5",
        "team_points_prev3","team_avg_finish_prev3","team_points_prev5","team_avg_finish_prev5",
        "drv_circuit_avg_finish_prev2"]
    extra_feats=["pit_count","avg_pit_ms","min_pit_ms","max_pit_ms","avg_lap_ms","best_lap_ms","laps_completed",
                 "airTemp","trackTemp","humidity","pressure","windSpeed","weatherDesc"]
    feature_cols=base_feats+extra_feats

    usable=df.dropna(subset=["finish_pos"]).copy()
    for c in feature_cols:
        usable[c]=usable[c].fillna(usable[c].mean())
    keys=["raceId","driverId","constructorId","circuitId","raceName","raceDateTime","driverRef","constructorRef"]
    final_cols=keys+feature_cols+["finish_pos","positionOrder","points"]
    return usable[final_cols].reset_index(drop=True),feature_cols

