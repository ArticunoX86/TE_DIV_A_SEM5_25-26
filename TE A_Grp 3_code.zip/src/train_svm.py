import argparse
import os
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.impute import SimpleImputer
from features import build_dataset


def train_svm(df, feature_cols, model_path):
    # Handle missing values
    df = df.copy()
    df = df.dropna(subset=["positionOrder"])  # Ensure target column has no NaNs

    X = df[feature_cols].values
    y = df["positionOrder"].values

    # Impute missing values in X
    imputer = SimpleImputer(strategy="mean")
    X = imputer.fit_transform(X)

    # Split data
    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_val_scaled = scaler.transform(X_val)

    # Initialize SVM regressor
    print("🚀 Training SVM model ...")
    model = SVR(kernel="rbf", C=10, gamma="scale")

    # Train model
    model.fit(X_train_scaled, y_train)

    # Evaluate model
    preds = model.predict(X_val_scaled)
    rmse = np.sqrt(mean_squared_error(y_val, preds))
    mae = mean_absolute_error(y_val, preds)

    print(f"✅ Validation RMSE: {rmse:.4f}")
    print(f"✅ Validation MAE: {mae:.4f}")

    # Save model + scaler + imputer
    save_data = {
        "model": model,
        "scaler": scaler,
        "imputer": imputer,
    }
    joblib.dump(save_data, model_path)

    return rmse, mae


def main(args):
    # Load dataset
    print("📂 Building dataset...")
    df, feature_cols = build_dataset(args.data_dir)

    # Ensure output directory exists
    os.makedirs(args.models_dir, exist_ok=True)

    model_path = os.path.join(args.models_dir, "svm_f1_model.joblib")
    feature_list_path = os.path.splitext(model_path)[0] + "_features.json"

    rmse, mae = train_svm(df, feature_cols, model_path)

    # Save feature list
    with open(feature_list_path, "w", encoding="utf-8") as f:
        json.dump(feature_cols, f, indent=2)

    print(f"\n💾 Saved model: {model_path}")
    print(f"💾 Saved feature list: {feature_list_path}")
    print(f"📊 Metrics: RMSE={rmse:.4f}, MAE={mae:.4f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=str, default="data/raw")
    parser.add_argument("--models-dir", type=str, default="models")
    args = parser.parse_args()
    main(args)
