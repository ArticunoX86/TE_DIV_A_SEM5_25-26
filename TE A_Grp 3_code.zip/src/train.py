# src/train.py
import argparse
import os
import json
import joblib
import numpy as np
import pandas as pd
from xgboost import XGBRegressor
from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_absolute_error, mean_squared_error
from features import build_dataset

def temporal_train_val_split(df: pd.DataFrame, test_year: int = None):
    years = sorted(df["raceDateTime"].dt.year.dropna().unique().tolist())
    if not years:
        raise ValueError("Could not infer years from raceDateTime. Check your CSVs.")
    max_year = max(years)
    if test_year is None:
        test_year = max_year
    train = df[df["raceDateTime"].dt.year < test_year].copy()
    valid = df[df["raceDateTime"].dt.year == test_year].copy()
    if train.empty or valid.empty:
        # Fallback: use last season as valid
        cutoff = max_year
        train = df[df["raceDateTime"].dt.year < cutoff].copy()
        valid = df[df["raceDateTime"].dt.year == cutoff].copy()
        test_year = cutoff
    return train, valid, test_year

def evaluate(y_true, y_pred):
    rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))

    mae = float(mean_absolute_error(y_true, y_pred))

    return {"rmse": float(rmse), "mae": float(mae)}

def main(args):
    df, feature_cols = build_dataset(args.data_dir)

    train, valid, test_year = temporal_train_val_split(df, args.test_year)

    X_tr = train[feature_cols].values
    y_tr = train["finish_pos"].values
    X_va = valid[feature_cols].values
    y_va = valid["finish_pos"].values

    # GroupKFold by raceId to avoid leakage within the same race
    gkf = GroupKFold(n_splits=5)
    groups = train["raceId"].values

    # Base model; you can tune later
    base_params = dict(
        n_estimators=args.n_estimators,
        learning_rate=args.learning_rate,
        max_depth=args.max_depth,
        subsample=args.subsample,
        colsample_bytree=args.colsample_bytree,
        reg_alpha=args.reg_alpha,
        reg_lambda=args.reg_lambda,
        random_state=42,
        objective="reg:squarederror",
        n_jobs=-1,
        tree_method="hist"
    )

    # Fit on full training set (you can also CV average if you like)
    model = XGBRegressor(**base_params)
    model.fit(X_tr, y_tr, eval_set=[(X_va, y_va)], verbose=False)

    metrics = evaluate(y_va, model.predict(X_va))
    os.makedirs(args.models_dir, exist_ok=True)

    model_path = os.path.join(args.models_dir, f"xgb_f1_{test_year}.joblib")
    feat_path = os.path.join(args.models_dir, f"xgb_f1_{test_year}_features.json")
    meta_path = os.path.join(args.models_dir, f"xgb_f1_{test_year}_metrics.json")

    joblib.dump(model, model_path)
    with open(feat_path, "w", encoding="utf-8") as f:
        json.dump(feature_cols, f, indent=2)
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump({"test_year": int(test_year), "metrics": metrics}, f, indent=2)

    print(f"Saved model: {model_path}")
    print(f"Validation metrics on {test_year}: {metrics}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=str, default="data/raw")
    parser.add_argument("--models-dir", type=str, default="models")
    parser.add_argument("--test-year", type=int, default=None)
    parser.add_argument("--n-estimators", type=int, default=700)
    parser.add_argument("--learning-rate", type=float, default=0.05)
    parser.add_argument("--max-depth", type=int, default=6)
    parser.add_argument("--subsample", type=float, default=0.9)
    parser.add_argument("--colsample-bytree", type=float, default=0.9)
    parser.add_argument("--reg-alpha", type=float, default=0.0)
    parser.add_argument("--reg-lambda", type=float, default=1.0)
    args = parser.parse_args()
    main(args)
