from flask import Flask, render_template, request, jsonify
import joblib
import pandas as pd
import numpy as np
import os
import json
from src.features import build_dataset

app = Flask(__name__, template_folder="templates", static_folder="static")

# -----------------------------
#  Load Models
# -----------------------------
XGB_MODEL_PATH = "models/xgb_f1_2024.joblib"
SVM_MODEL_PATH = "models/svm_f1_model.joblib"

xgb_model = joblib.load(XGB_MODEL_PATH)
svm_model = joblib.load(SVM_MODEL_PATH)

# -----------------------------
#  Load Feature Lists (JSON)
# -----------------------------
with open("models/xgb_f1_2024_features.json", "r") as f:
    XGB_FEATURES = json.load(f)

with open("models/svm_f1_model_features.json", "r") as f:
    SVM_FEATURES = json.load(f)


# -----------------------------
#  ROUTES
# -----------------------------
@app.route("/")
def home():
    return render_template("index.html")


@app.route("/history")
def history():
    return render_template("history.html")


@app.route("/project")
def project():
    return render_template("project.html")


# -----------------------------
#  Prediction Endpoint
# -----------------------------
@app.route("/predict", methods=["GET"])
def predict():

    # Get Year + Model Type from URL
    year = int(request.args.get("year"))
    model_type = request.args.get("model", "xgb").lower()

    # Build dataset from raw CSVs
    df, _ = build_dataset("data/raw")

    # Filter only requested year
    df_year = df[df["raceDateTime"].dt.year == year].copy()

    if df_year.empty:
        return jsonify({"error": f"No race data found for year {year}"}), 404

    # -----------------------------
    # Select Model + Features
    # -----------------------------
    if model_type == "svm":
        model = svm_model
        model_features = SVM_FEATURES
    else:
        model = xgb_model
        model_features = XGB_FEATURES

    # Ensure missing feature columns exist
    for col in model_features:
        if col not in df_year.columns:
            df_year[col] = df_year[col].mean()

    # Prepare X
    X = df_year[model_features].values

    # Predict
    pred = model.predict(X)
    df_year["pred"] = pred

    # Rank inside each race
    df_year["pred_rank"] = (
        df_year.groupby("raceId")["pred"]
        .rank(method="first", ascending=True)
    )

    # Build output
    output = df_year[[
        "raceId", "raceName", "raceDateTime",
        "driverId", "driverRef", "constructorRef",
        "pred", "pred_rank", "positionOrder"
    ]].sort_values(["raceId", "pred_rank"])

    # Convert datetime to string for JSON
    output["raceDateTime"] = output["raceDateTime"].astype(str)

    return jsonify(output.to_dict(orient="records"))


# -----------------------------
#  RUN SERVER
# -----------------------------
if __name__ == "__main__":
    app.run(debug=True)
