# F1 Race Prediction with XGBoost — Extended Features

This version includes **pit stop stats, lap times, and weather data** as additional features.

## Extra CSVs needed in `data/raw/`

- `pit_stops.csv` → stop, lap, time, duration, milliseconds
- `lap_times.csv` → lap, position, time, milliseconds
- `weather.csv` → (custom) race-level: raceId, airTemp, trackTemp, humidity, pressure, windSpeed, weatherDesc

If unavailable, the pipeline fills them with NaNs (safe to run).

## Usage

Same as the starter version:

```bash
python src/train.py --data-dir data/raw --models-dir models
python src/predict.py --data-dir data/raw --models-dir models --out data/processed/predictions.csv
```
